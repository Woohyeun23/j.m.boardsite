package Member;

import Utill.Ci;
import Utill.Cw;
import Utill.Db;

public class ProcMemberLogin {

	public static String run() {
		Cw.wn("================== - 로그인 - =====================");
		String id = "";
		String pw = "";
		while(true) {
			id = Ci.r("id");
			if(id.length() > 0) {
				break;
			}else {
				Cw.wn();
				Cw.wn("다시 입력해주세요");
			}
		}
		
		while(true) {
			pw = Ci.r("passward");
			if(pw.length() > 3) {
				break;
			} else {
				Cw.wn();
				Cw.wn("다시 입력해주세요");
			}
		}
		
		if(Db.isProcLogin(id, pw)) {
			return id;
		} else {
			return null;
		}
		
		
		
		
	}
	
}
