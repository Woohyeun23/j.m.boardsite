package Board_Main;

import Utill.Ci;
import Utill.Db;

public class ProcUpdate {

	public static void run() {
		System.out.println("글 수정 기능을 실행합니다");
		System.out.println("");
		String editNo = Ci.r("수정할 글 번호를 입력해주세요");
		if(editNo.equals("x")) {
			System.out.println("이전 메뉴로 돌아갑니다");
			return;
		}
		
		
		String ed_title = Ci.rl("수정할 글 제목을 입력해주세요");
		
		String ed_id = Ci.r("수정할 id를 입력해주세요");
		
		String ed_cont = Ci.rl("수정할 내용을 기입해주세요");
		
		Db.dbExecuteUpdate("update sec_board set b_title ='" + ed_title + "', b_id ='" +ed_id+ "', b_datetime = now(), b_text ='"+ed_cont+"' where b_no =" +editNo );
		
	}
}
