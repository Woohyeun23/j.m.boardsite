package Board_Main;

import java.util.Scanner;

import Display.Disp;
import Utill.Ci;
import Utill.Cw;
import Utill.Db;

public class ProcBoard {
	
	
	Scanner sc = new Scanner(System.in);
	
	public static void run() {
		 Db.dbInit();
//		dbExecuteQuery("select * from tottenham_squad where p_number=7");
		loop:
			while(true) {
//				Disp.showTitle();
				Disp.showMainMenu();
				String cmd = Ci.r("명령어를 입력해주세요");
				switch(cmd) {
				case "1":
					ProcList.run();
					break;
					
				case "2":
					ProcRead.run();
					break;
					
				case "3":
					ProcWrite.run();
					break;
					
				case "4":
					String s = ProcDel.run();
					if(s.equals("x") || s.equals("fail")) {
						Cw.wn("이전 메뉴로 이동합니다");
						break;
					}
					
					Db.dbExecuteUpdate(s);
					break;
					
				case "5":
					ProcUpdate.run();
					break;
					
				case "6":
					ProcList.search();
					break;
					
					
				case "0":
					System.out.println("임시 관리자 기능 실행");
					break loop;
				}
				
				
			}
		
		
		
		
	}
	
	
}
