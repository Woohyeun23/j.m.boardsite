package Site;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import Board_Main.ProcBoard;

public class Main {
	public static void main(String[] args) {
		SiteMain.run();
	}
	
	

}
