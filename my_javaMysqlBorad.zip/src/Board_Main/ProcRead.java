package Board_Main;

import java.sql.SQLException;

import Utill.Ci;
import Utill.Cw;
import Utill.Db;

public class ProcRead {
	public static void run() {
		System.out.println("읽기 기능을 실행합니다");
		String ReadNo = Ci.r("읽을 글 번호를 입력해주세요");
		try {
			Db.result = Db.st.executeQuery("select * from sec_board where b_no ="+ReadNo);
			Db.result.next();
			String title = Db.result.getString("b_title");
			String content = Db.result.getString("b_text");
			System.out.println("글 제목 :" + title);
			System.out.println("글 내용 :" + content);
	
		ProcReply.list(Integer.parseInt(ReadNo));
		
		loop :
			while(true) {
				String cmd = Ci.r("명령 : r.댓글달기 , x.뒤로 가기");
				switch(cmd) {
				case "r":
					ProcReply.write(Integer.parseInt(ReadNo));
					break;
				case "x":
					Cw.wn("이전 메뉴로 이동합니다");
					break loop;
				default :
					Cw.wn("그런 명령은 없습니다");
				
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
		
	}

}
