package Board_Main;

import java.sql.SQLException;

import Display.Disp;
import Utill.Ci;
import Utill.Cw;
import Utill.Db;

public class ProcList {
	public static final int PER_PAGE = 3;
	
	static int startIndex = 0;
	static int currentPage = 1;
	static boolean isSearchMode = false;
	static int totalPage = 0;
	static int count = 0;
	static String cmd = "";

	public static void run() {
		System.out.println("리스트 기능을 실행합니다");
		count = Db.getPostCount();
		if(count % PER_PAGE > 0) {
			totalPage = count / PER_PAGE + 1;
		} else {
			totalPage = count / PER_PAGE;
		}
		Cw.wn("총 페이지 수 : " +totalPage);
		
		while(true) {
			cmd = Ci.r("페이지 번호 입력 [x.이전 메뉴로]");
			if(cmd.equals("x")) {
				Cw.wn("이전 메뉴로 돌아갑니다");
				break;
			}
			currentPage = Integer.parseInt(cmd);
			if(currentPage > totalPage || currentPage <0) {
				Cw.wn("다시 입력하세요");
				continue;
			} 
			startIndex = (currentPage-1)*PER_PAGE;
		Disp.titleList();
		String sql = "select * from sec_board where reply_ori is null limit " +startIndex + ","+PER_PAGE;
		try {
			Cw.wn(sql);
			Db.result = Db.st.executeQuery(sql);
//			Db.result = Db.st.executeQuery("select * from sec_board where reply_ori is null limit "+startIndex+","+PER_PAGE);
			while(Db.result.next()){
			String no = Db.result.getString("b_no");
			String title = Db.result.getString("b_title");
			String id = Db.result.getString("b_id");
			String datetime = Db.result.getString("b_datetime");
			System.out.println(no + " " + title + " " +id + " " + datetime);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		}
	}
	
	public static void search() {
		cmd = Ci.rl("검색어 ( x.나가기 )");
		if(cmd.equals("x")) {
			return;
		} else {
			searchList(cmd);
		}
	}
	
	public static void searchList(String searchword) {
		count = Db.getPostCountSearch(searchword);
		if(count%PER_PAGE >0) {
			totalPage = count / PER_PAGE + 1;
		} else {
			totalPage = count / PER_PAGE;
		}
		Cw.wn("총 페이지 수 : " + totalPage);
		while(true) {
			cmd = Ci.r("페이지 번호 입력<검색 모드> [x. 이전 메뉴]");
			if(cmd.equals("x")) {
				Cw.wn("이전 메뉴로 이동합니다");
				break;
			}
			currentPage = Integer.parseInt(cmd);
			if(currentPage > totalPage || currentPage<0){
				Cw.wn("다시 입력해주세요");
				continue;
			}
			startIndex = (currentPage - 1)* PER_PAGE;
			Disp.titleList();
			String sql = "select * from sec_board where reply_ori is null " 
			+"and b_title like '%" +searchword+"%' limit "+startIndex + "," +PER_PAGE;
			try {
				Cw.wn("전송한 구문" + sql);
				Cw.wn();
				Db.result = Db.st.executeQuery(sql);
				while(Db.result.next()) {
					String no = Db.result.getString("b_no");
					String title = Db.result.getString("b_title");
					String id = Db.result.getString("b_id");
					String datetime = Db.result.getString("b_datetime");
					Cw.wn(no + " " + title + " " +id + " " + datetime);
				}
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
		
		
		
	}
	
	
}
