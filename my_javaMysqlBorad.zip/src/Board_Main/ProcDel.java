package Board_Main;

import Site.SiteMain;
import Utill.Ci;
import Utill.Cw;
import Utill.Db;

public class ProcDel {
	
	public static String run() {
		String DelNo = Ci.r("삭제할 번호를 입력해주세요");
		Cw.wn();
		if(DelNo.equals("x")) {
			Cw.wn("뒤로 이동합니다");
			return DelNo;
		}
		 String sql = "delete from sec_board where b_no ="+DelNo +" and b_id ='"+SiteMain.LoginedId+"'";
		 
		 if(Db.isProcDel(DelNo, SiteMain.LoginedId)) {
			 
			 return sql;
		 } else {
			 Cw.wn("삭제할 게시글이 없습니다");
			 return "fail";
		 }
		 
		 
		 
		 
		 
		
	}
}
