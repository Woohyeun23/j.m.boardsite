package Member;

import Utill.Ci;
import Utill.Cw;
import Utill.Db;

public class ProcMemberRegister {

	static private String cmd = "";
	
	public static void run() {
		String id = "";
		String pw = "";
		
		while(true) {
			Cw.wn();
			id = Ci.r("사용할 아이디를 입력해주세요");
			if(id.length() > 0) {
				break;
			} else {
				Cw.wn("글자 수가 너무 적습니다");
			}
		}	
		
		while(true) {
			Cw.wn();
			pw = Ci.r("사용할 비밀번호를 입력해주세요");
			if(pw.length() > 3) {
				break;
			}
		}
		Cw.wn("insert into sec_member values ('" +id+"', '"+pw+"')");
		Db.dbExecuteUpdate("insert into sec_member values ('" +id+"','"+pw+"')");
		Cw.wn("가입이 완료되었습니다");
		
	}
	
}
