package Display;

import Utill.Cw;

public class SiteDisp {

	static private String SITE_NAME = "팀BEAST";
	static private String VERSION = "0.0.1V";
	static private String FEAT = "(feat.Luna)";
	
	public static void siteTitle() {
		Cw.line();
		Cw.dot();
		Cw.space(17);
		Cw.w(SITE_NAME);
		Cw.w(VERSION);
		Cw.w(FEAT);
		Cw.space(17);
		Cw.dot();
		Cw.wn();
		Cw.line();
		
	}
	
	
	
	
	
	
	
	
}
