package Board_Main;

import java.sql.SQLException;

import Site.SiteMain;
import Utill.Ci;
import Utill.Cw;
import Utill.Db;

public class ProcWrite {

	public static void run() {
	
		String title;
		while(true) {
		title = Ci.rl("글 제목을 입력해주세요 ");
		if(title.length() > 0) {
			break;
		} else {
			Cw.wn("글자 수가 부족합니다");
		}
		}
		
		
		String content;
		while(true) {
			content = Ci.rl("내용을 입력해주세요");
			if(content.length() > 5) {
				break;
			} else {
				Cw.wn("글자 수가 부족합니다");
			}
		}
		
		String sql = String.format("insert into sec_board (b_title, b_id, b_datetime, b_text, b_hit) values ("
				+ "'%s', '%s', now(), '%s', 0)", title, SiteMain.LoginedId, content) ;
		Cw.wn(sql);
		
		try {
			Db.st.executeUpdate(sql);
			Cw.wn("글 등록 완료");
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
	}
}
