package Utill;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Utill.Db;

public class Db {
	static private String DB_NAME = "my_cat";
	static private String DB_ID = "root";
	static private String DB_PW = "root";
	
	public static Connection con = null;
	public static Statement st = null;
	public static ResultSet result =null;
	
	public static void dbInit() {
		try {
			Db.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			Db.st = Db.con.createStatement();	// Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet 객체만을 열 수있다.
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	public static void dbExecuteUpdate(String query) {
		try {
			int resultCount = Db.st.executeUpdate(query);
			System.out.println("처리된 행 수:"+resultCount);
		} catch (SQLException e) {
			e.printStackTrace();
//			System.out.println("SQLException: " + e.getMessage());
//			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	public static void dbPostCount() {
		String count = ""; //그냥 int count;해서 나중에 형변환 없이 가져와도 됨
		try {
			Db.result = Db.st.executeQuery("select count(*) from sec_board where reply_ori is null");
			Db.result.next();
			count = Db.result.getString("count(*)");// int로 했을때 count = Db.result.getInt("count(*)")로 해도됨
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static int getPostCount() {
		String count = ""; //아님 null
		try {
			Db.result = Db.st.executeQuery("select count(*) from sec_board where reply_ori is null");
					Db.result.next();
			count = Db.result.getString("count(*)");
		}catch (SQLException e) {
			e.printStackTrace();
		}
		int intCount = Integer.parseInt(count);
		return intCount;
	}
	
	
	public static int getPostCountSearch(String searchWord) {
		String count = ""; //아님 null
		try {
			Db.result = Db.st.executeQuery("select count(*) from sec_board where reply_ori is null"
					+ " and b_title like '%" +searchWord+"%' ");
			Db.result.next();
			count = Db.result.getString("count(*)");
			Cw.wn("글수 :" +count);
		}catch (SQLException e) {
			e.printStackTrace();
		}
		int intCount = Integer.parseInt(count);
		return intCount;
	}
	
	
//	public static int getPostCount() {
//		int count = 0;
//		try {
//			Db.result =Db.st.executeQuery("select count(*) from sec_board where reply_ori is null");
//			Db.result.next();
//			count = Db.result.getInt("count(*)");
//		}catch (SQLException e) {
//			e.printStackTrace();
//		}
//		return count;
//		
//		
//		
//	}
//	
//
//public static int getPostCountSearch(String searchWord) {
//	int count = 0;
//	try {
//		Db.result =Db.st.executeQuery("select count(*) from sec_board where reply_ori is null"
//				+" and b_title like '" +searchWord+"'");
//		Db.result.next();
//		count = Db.result.getInt("count(*)");
//	}catch (SQLException e) {
//		e.printStackTrace();
//	}
//	return count;
//	
//	
//	
//}
	public static boolean isProcLogin(String id, String pw) {
		String count = "";
		try {
//			String sql = "select count(*) from sec_member where s_id ='"+ id +
//					"' and s_pw ='" +pw+"'";
			String sql = String.format("select count(*) from sec_member where s_id = '%s'and s_pw = '%s'"
					, id, pw);
//			Cw.wn(sql);
			Db.result = Db.st.executeQuery(sql);
					
					Db.result.next();
					count = Db.result.getString("count(*)");
					Cw.wn("찾은 회원 수 :" + count);
		
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		if(count.equals("1")) {
			Cw.wn("로그인 성공!");
			return true;
		} else {
			Cw.wn("로그인 실패...");
			return false;
		}
		
	}
	
	
	public static boolean isProcDel (String DelNo, String id) {
		String count = "";
		try {
			Db.result = Db.st.executeQuery("select count(*) from sec_board where b_no ='" +DelNo
					+"' and b_id ='"+id+"'");
			Db.result.next();
			count = Db.result.getString("count(*)");
			Cw.wn("처리할 게시물 : " + count);
		}catch (SQLException e) {
			e.printStackTrace();
		}
		if(count.equals("1")) {
			return true;
		} else {
			Cw.wn("해당 번호의 게시물이 없음");
			return false;
		}
	}
	
	
}
