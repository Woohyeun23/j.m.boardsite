package Board_Main;

import java.sql.SQLException;

import Display.Disp;
import Site.SiteMain;
import Utill.Ci;
import Utill.Cw;
import Utill.Db;

public class ProcReply {

	public static void list(int oriNo) {
		Cw.wn();
		Disp.replyline();
		String sql = "select * from sec_board where reply_ori = " +oriNo;
		try {
			Cw.wn(sql);
			Db.result = Db.st.executeQuery(sql);
			while(Db.result.next()) {
				String reply_con = Db.result.getString("reply_con");
				 String b_id = Db.result.getString("b_id");
				Cw.wn(reply_con +" 작성자id : " + b_id);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		Cw.wn();
	}
	
	public static void write(int reply_ori) {
		String reply_con = Ci.rl("댓글을 입력해주세요");
		if(reply_con.equals("x")) {
		Cw.wn("댓글을 쓰지 않고 넘어갑니다");
		
		}else {
			Db.dbExecuteUpdate("insert into sec_board (b_id, b_datetime, reply_ori, reply_con)"
					+ "values('"+SiteMain.LoginedId+"', now(), "+reply_ori+", '"+reply_con+"')");
		}
		
		
		
	}
	
	
	
	
	
	
	
	
}
