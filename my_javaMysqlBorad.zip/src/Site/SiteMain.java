package Site;

import Board_Main.ProcBoard;
import Display.SiteDisp;
import Member.ProcMemberLogin;
import Member.ProcMemberRegister;
import Utill.Ci;
import Utill.Cw;
import Utill.Db;

public class SiteMain {
	static private String cmd = "";
	public static String LoginedId = null;

	public static void run() {
		Db.dbInit();
		
		loop : 
			while(true) {
				SiteDisp.siteTitle();
				if(LoginedId == null) {
					cmd = Ci.r("[r]회원 가입 [l]로그인 [e]프로그램 종료");
				} else {
					Cw.wn();
					Cw.w("---");
					Cw.wn(LoginedId+"고객님 환영합니다");
					Cw.w("---");
					Cw.wn();
					cmd = Ci.r("[l]로그아웃 [b]게시판 [a]관리자 모드 [e]프로그램 종료");
				}
				
				switch(cmd) {
				case "r":
					if(LoginedId == null) {
						ProcMemberRegister.run();
					} else {
						Cw.wn("그런 기능은 없습니다");
					}
					break;
				case "l": 
					if(LoginedId == null) {
						LoginedId = ProcMemberLogin.run();
					} else {
						Cw.wn("로그아웃 성공!");
						LoginedId = null;
					}
					break;
				case "a":
					break;
				case "b":
					if(LoginedId == null) {
						Cw.wn("아직 실행할 수 없습니다");
					} else {
						ProcBoard.run();
					}
					break;
				case "e":
					Cw.wn("프로그램을 종료합니다");
					Ci.rl("아무키나 입력해주세요");
					break loop;
					
					
					
				default :
					Cw.wn("그런 명령을 없습니다");
					Cw.wn();
					
				}
				
				
				
				
				
				
				
				
			}
		
		
	}
	
	
}
